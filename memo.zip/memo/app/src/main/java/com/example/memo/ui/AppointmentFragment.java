package com.example.memo.ui;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.Toast;

import com.example.memo.R;
import com.example.memo.ui.pet.PetFragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.onesignal.OneSignal;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;

public class AppointmentFragment extends Fragment {
    final int SEND_SMS_PERMISSION_REQUEST_CODE=1;
    CalendarView calendarView;
    static ArrayList<String> times = new ArrayList<>();
    static ArrayList<String> isFull= new ArrayList<>();
    String appday;
    String addTime;
    String isfull;
    private boolean clickedapp=false;
    Button but1;
    Button but;
    static ArrayList<String> Applist = new ArrayList<>();
    long counterapp;
    int xo;
    String avapId;
    private DatabaseReference ref,ref1,dataref;
    private static String petID;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View root = inflater.inflate(R.layout.fragment_appointment, container, false);
        SharedPreferences prefuser = this.getActivity().getSharedPreferences("prefuser", Context.MODE_PRIVATE);
        String userID=prefuser.getString("userid","");
        SharedPreferences pref = this.getActivity().getSharedPreferences("pref", Context.MODE_PRIVATE);
        String vetID=pref.getString("vetid","");
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getContext(), android.R.layout.simple_list_item_1, times);
        petID= PetFragment.getPetId();
        ref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Appointment");
        ref1 =FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("availableApp");
        dataref=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        but= root.findViewById(R.id.Timer);
        but1=root.findViewById(R.id.getApp);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counterapp=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        but1.setVisibility(View.INVISIBLE);
        calendarView= root.findViewById(R.id.calenderview);
        calendarView.setMinDate(System.currentTimeMillis() - 1000);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                month+=1;
                times.clear();
                isFull.clear();
                if (dayOfMonth<10){
                    String dayy="0"+dayOfMonth;
                    if (month<10){
                        String monthh="0"+month;
                        appday=dayy+"."+monthh+"."+year;
                    }
                    else{
                        appday=dayy+"."+month+"."+year;
                    }
                }
                else {
                    if (month<10){
                        String monthh="0"+month;
                        appday=dayOfMonth+"."+monthh+"."+year;
                    }
                    else {
                        appday=dayOfMonth+"."+month+"."+year;
                    }
                }
                System.out.println(appday);
            };
        });
        View row=inflater.inflate(R.layout.popup_app, container, false);
        ListView lst=row.findViewById(R.id.lstid);
        Button adderbut=row.findViewById(R.id.buttonaddo);

        final PopupWindow popupWindow = new PopupWindow(row, 800, 900, true);
        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.showAtLocation(root, Gravity.CENTER, 0, 0);
                adderbut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {//dolaşacak boş zamanları
                        if (times.isEmpty()){
                            ref1.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                                        String chosenday=snapshot.child("day").getValue().toString();
                                        String chosenvet=snapshot.child("vetID").getValue().toString();
                                        System.out.println(chosenday);
                                        if (chosenday.equals(appday)&&vetID.equals(chosenvet)){
                                            long childCounter=snapshot.getChildrenCount()-3;
                                            avapId=snapshot.child("availableDay").getValue().toString();
                                            int ino=0;
                                            while (ino<childCounter){
                                                if (snapshot.child("time"+ino).exists()){
                                                    times.add(snapshot.child("time"+ino).child("time").getValue().toString());
                                                    isFull.add(snapshot.child("time"+ino).child("empty").getValue().toString());
                                                    ino++;
                                                }
                                            }
                                            System.out.println(times);

                                            break;
                                        }
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }

                    if (!times.isEmpty()){
                        lst.setAdapter(adapter);
                        }

                    }
                });
                lst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        addTime=times.get(position);
                        isfull=isFull.get(position);
                        if (isfull.equals("true")){
                            Toast.makeText(getContext(), "This time is already created.", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            but1.setVisibility(View.VISIBLE);
                            popupWindow.dismiss();
                        }
                    }
                });
            }
        });

        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Appointment app = new Appointment(vetID,counterapp,userID,appday,addTime);
            clickedapp=true;
            Appointment newapp = new Appointment(vetID,app.getCounterApp()+1,userID,appday,addTime);
            ref.child(newapp.getAppId()).setValue(newapp);
                for (int i=0;i<times.size();i++){
                    if (times.get(i).equals(addTime)){
                        xo=i;
                    }
                }
                final HashMap<String,Object> dataTimer = new HashMap<>();
                dataTimer.put("empty",true);
                dataTimer.put("time",addTime);
                dataTimer.put("timeId","time"+xo);
                ref1.child(avapId).child("time"+xo).updateChildren(dataTimer);
                Toast.makeText(getContext(), "Appointment added chosen date and Time", Toast.LENGTH_SHORT).show();
                String userId = OneSignal.getDeviceState().getUserId();
                try {
                    OneSignal.postNotification(new JSONObject("{'contents': {'en':'"+"Appointment added"+addTime+"and"+appday+"'}, 'include_player_ids': ['" + userId + "']}"), null);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        if (clickedapp){
            but1.setVisibility(View.INVISIBLE);
        }

        return root;
    }
}