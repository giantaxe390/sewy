package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.telecom.Call;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.onesignal.OneSignal;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.HashMap;

public class vetFrag extends AppCompatActivity {
    Button petAdds;
    Button appButt;
    Button appgetter;
    Button homes;
    Button activ;
    Button actwithapp;
    EditText name;
    EditText Vetpass;
    ImageView vetimg;
    EditText Location;
    private static final String ONESIGNAL_APP_ID = "34cb354e-e7ae-4b43-a451-ad4d60cbb920";
    String vetID;
    Button imageChanger;
    EditText phonenum;
    private String calledBy;
    String vetname,phon,loc,logpass;
    private String downloadUrl;
    private StorageReference userProfileImgRef;
    private static int GalleryPick=1;
    private Uri imageUri;
    private DatabaseReference vetref,petref,userref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vet_frag);
        vetimg=findViewById(R.id.vetimage);
        imageChanger=findViewById(R.id.imagechanger);
        appgetter=findViewById(R.id.appgetter);
        vetID = getIntent().getExtras().getString("VetID","defaultKey");
        vetref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Veterinary");
        userref=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        petref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Pet");
        userProfileImgRef= FirebaseStorage.getInstance().getReference().child("Profile Images");
        petAdds=findViewById(R.id.petAddbutt);
        appButt=findViewById(R.id.appbutt);
        name=findViewById(R.id.vetname);
        Vetpass=findViewById(R.id.loginpass);
        activ=findViewById(R.id.actadder1);
        actwithapp=findViewById(R.id.actadder);
        homes=findViewById(R.id.button5);
        Location=findViewById(R.id.vetloc);
        phonenum=findViewById(R.id.vetphone);
        name.setKeyListener(null);
        phonenum.setKeyListener(null);
        Location.setKeyListener(null);
        Vetpass.setKeyListener(null);
      /*  Intent i = new Intent(this, SendNotif.class);
        i.putExtra("sendUserId",vetID);
        startActivity(i);*/
        vetref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    if (vetID.equals(snapshot.child("vetId").getValue().toString())){
                        vetname=snapshot.child("vetName").getValue().toString();
                        phon=snapshot.child("phonenumber").getValue().toString();
                        loc=snapshot.child("address").getValue().toString();
                        logpass=snapshot.child("vetPass").getValue().toString();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        homes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name.setText(vetname);
                phonenum.setText(phon);
                Location.setText(loc);
                Vetpass.setText(logpass);
            }
        });
        Intent addpet=new Intent(this,petAdds.class);
        petAdds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addpet.putExtra("VetID",vetID);
                startActivity(addpet);
            }
        });
        Intent appPet=new Intent(this,AppointActivity.class);
        appButt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appPet.putExtra("VetIDD",vetID);
                startActivity(appPet);
                //android studio ajanda
            }
        });
        Intent actadd=new Intent(this,addPetact.class);
        activ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                actadd.putExtra("VetIDact",vetID);
                startActivity(actadd);
            }
        });
        Intent newappact=new Intent(this,nextAppointments.class);
        appgetter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newappact.putExtra("nextVetId",vetID);
                startActivity(newappact);
            }
        });
        Intent appact=new Intent(this,actWithApp.class);
        actwithapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                appact.putExtra("vetIdapp",vetID);
                startActivity(appact);
            }
        });
        vetimg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,GalleryPick);
            }
        });
        imageChanger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserData();
            }
        });
        OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);

        // OneSignal Initialization
        OneSignal.initWithContext(this);
        OneSignal.setAppId(ONESIGNAL_APP_ID);
        String userId = OneSignal.getDeviceState().getUserId();
        userref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                userref.child(vetID).child("playerID").setValue(userId);
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
        retriveVetInfo();

    }

    private void retriveVetInfo() {
        userref.child(vetID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (snapshot.child("image").exists()){
                    String imageDb=snapshot.child("image").getValue().toString();
                    Picasso.get().load(imageDb).placeholder(R.drawable.profile_image).into(vetimg);
                }
            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==GalleryPick && data!=null){
            imageUri=data.getData();
            vetimg.setImageURI(imageUri);
        }
    }
    private void saveUserData() {
        if (imageUri==null){
            Toast.makeText(this, "Please select Image first", Toast.LENGTH_SHORT).show();
        }
        else{
            final StorageReference filePath = userProfileImgRef.child(vetID);
            final UploadTask uploadTask=filePath.putFile(imageUri);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull @NotNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()){
                        throw task.getException();
                    }
                    downloadUrl=filePath.getDownloadUrl().toString();
                    return filePath.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<Uri> task) {
                    if (task.isSuccessful()){
                        downloadUrl=task.getResult().toString();
                        HashMap<String,Object> profileMap = new HashMap<>();
                        profileMap.put("vid",vetID);
                        profileMap.put("image",downloadUrl);
                        userref.child(vetID).updateChildren(profileMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    Toast.makeText(vetFrag.this, "Profile settings updated", Toast.LENGTH_SHORT).show();

                                }
                            }
                        });
                    }
                }
            });
        }
    }

    @Override
    protected void onStart() {
        super.onStart();

        checkForReceivingCall();
    }

    private void checkForReceivingCall() {
        userref.child(vetID)
                .child("Ringing")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                        if (snapshot.hasChild("ringing")){
                            calledBy=snapshot.child("ringing").getValue().toString();
                            Intent callingIntent = new Intent(vetFrag.this, CallingActivity.class);
                            callingIntent.putExtra("vetoId",calledBy);
                            callingIntent.putExtra("usoId",vetID);
                            callingIntent.putExtra("bool",false);
                            startActivity(callingIntent);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull @NotNull DatabaseError error) {

                    }
                });
    }

}