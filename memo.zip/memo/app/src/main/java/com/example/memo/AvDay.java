package com.example.memo;

public class AvDay {
    String availableDayId;
    String vetID;
    String day;


    public String getAvailableDay() {
        return availableDayId;
    }

    public void setAvailableDay(String ava) {
        this.availableDayId = ava;
    }

    public String getVetID() {
        return vetID;
    }

    public void setVetID(String vetID) {
        this.vetID = vetID;
    }

    public String getDay() {
        return day;
    }

    public void setDay(String day) {
        this.day = day;
    }



    public AvDay(long counter,String vet,String dayy) {

        this.availableDayId="avaApp"+counter;
        this.vetID=vet;
        this.day=dayy;

    }
    public AvDay() {
    }
}
