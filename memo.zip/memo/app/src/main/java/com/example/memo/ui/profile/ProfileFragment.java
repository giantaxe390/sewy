package com.example.memo.ui.profile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.memo.R;
import com.example.memo.ui.home.HomeFragment;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

public class ProfileFragment extends Fragment {
    EditText userName;
    EditText userPhone;
    EditText userSurname;
    EditText userMail;
    Button passc;
    Button imgchanger;

    ImageView profim;
    DatabaseReference userref,uimageref;
    ProgressDialog progressDialog;
    private static String username;
    private static String userpass;
    String userID;
    private static String usersurname;
    private String downloadUrl;
    private static String userphone;
    private StorageReference userProfileImgRef;
    private static String usermail;
    private static int GalleryPick=1;
    private Uri imageUri;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_profile, container, false);
        SharedPreferences prefuser = this.getActivity().getSharedPreferences("prefuser", Context.MODE_PRIVATE);
        userID=prefuser.getString("userid","");
        userName=root.findViewById(R.id.editTextPersonName);
        userSurname=root.findViewById(R.id.editTextPersonSurname);
        userPhone=root.findViewById(R.id.editTextphone);
        profim=root.findViewById(R.id.profileimage);
        userMail=root.findViewById(R.id.editTextmail);
        passc=root.findViewById(R.id.passchanger);
        userName.setKeyListener(null);
        userSurname.setKeyListener(null);
        userPhone.setKeyListener(null);
        userMail.setKeyListener(null);
        progressDialog = new ProgressDialog(getContext());
        userProfileImgRef= FirebaseStorage.getInstance().getReference().child("Profile Images");
        imgchanger=root.findViewById(R.id.avatarChanger);
        uimageref=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        userref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("User");
        userref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    if (userID.equals(snapshot.child("userId").getValue().toString())){
                        username=snapshot.child("name").getValue().toString();
                        usersurname=snapshot.child("userId").getValue().toString();
                        userphone= snapshot.child("phone").getValue().toString();
                        usermail=snapshot.child("mail").getValue().toString();
                        userpass=snapshot.child("password").getValue().toString();
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        userName.setText("Name: "+username);
        userSurname.setText("Surname : "+usersurname);
        userPhone.setText("Phone: "+userphone);
        userMail.setText("E-mail : "+usermail);
        View popupView = inflater.inflate(R.layout.popup_resetpass, null);
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
        // show the popup window
        // which view you pass in doesn't matter, it is only used for the window tolken
        passc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.showAtLocation(container, Gravity.CENTER, 0, 0);
                Button changebut=popupView.findViewById(R.id.videoCall);
                EditText old=popupView.findViewById(R.id.actType);
                EditText newp=popupView.findViewById(R.id.actDate);
                changebut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String oldy=old.getText().toString();
                        String newone=newp.getText().toString();
                        userref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                                       if (userpass.equals(oldy)){
                                           userref.child(snapshot.child("userId").getValue().toString()).child("password").setValue(newone);
                                       }
                                       else{
                                           System.out.println("wrong pass");
                                       }
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                });


            }
        });
        profim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent,GalleryPick);
            }
        });
        imgchanger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserData();
            }
        });
        retriveUserInfo();
        return root;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode==GalleryPick && data!=null){
            imageUri=data.getData();
            profim.setImageURI(imageUri);
        }
    }
    private void saveUserData(){
        if (imageUri==null){
            Toast.makeText(getActivity(), "Please select Image first", Toast.LENGTH_SHORT).show();
        }
        else {
            progressDialog.setTitle("Account Settings");
            progressDialog.setMessage("Please Wait");
            progressDialog.show();
            final StorageReference filePath = userProfileImgRef.child(userID);
            final UploadTask uploadTask=filePath.putFile(imageUri);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull @NotNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                    if (!task.isSuccessful()){
                        throw task.getException();
                    }
                    downloadUrl=filePath.getDownloadUrl().toString();
                    return filePath.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                @Override
                public void onComplete(@NonNull @NotNull Task<Uri> task) {
                    if (task.isSuccessful()){
                        downloadUrl=task.getResult().toString();
                        HashMap<String,Object> profileMap = new HashMap<>();
                        profileMap.put("uid",userID);
                        profileMap.put("image",downloadUrl);
                        uimageref.child(userID).updateChildren(profileMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<Void> task) {
                                if (task.isSuccessful()){
                                    progressDialog.dismiss();
                                    Toast.makeText(getActivity(), "Profile settings updated", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
                    }
                }
            });
        }

    }
    private void retriveUserInfo(){
        uimageref.child(userID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (snapshot.child("image").exists()){
                    String imageDb=snapshot.child("image").getValue().toString();
                    Picasso.get().load(imageDb).placeholder(R.drawable.profile_image).into(profim);
                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }
}