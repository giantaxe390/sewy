package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.example.memo.ui.pet.PetActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class actWithApp extends AppCompatActivity {
    private DatabaseReference appdat,petdat,vacdat,meddat,actdatabase;
    Button petbut;
    String userId;
    Button reff;
    ListView getVaclst;
    Button actbut;
    boolean isApp;
    String lastname;
    String appointmentId;
    String typee;
    String realdete;
    NumberPicker numPicker;
    final String sub[] ={"Shaving", "Vaccines", "Medicines"};
    ListView petlst;
    long counter;
    String appdate;//user tarafına notifications ekle activity eklendiğinde rapora bak
    TextView infotxt;
    static ArrayList<String> pastappId = new ArrayList<>();
    static ArrayList<String> datelist = new ArrayList<>();
    static ArrayList<String> pastappuser = new ArrayList<>();
    static ArrayList<String> petIdlist = new ArrayList<>();
    static ArrayList<String> petnamelist = new ArrayList<>();
    static ArrayList<String> vaccinelst = new ArrayList<>();
    static ArrayList<String> vaccineidlst = new ArrayList<>();
    static ArrayList<String> medlst = new ArrayList<>();
    static ArrayList<String> medidlst = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_act_with_app);
        String vetID = getIntent().getExtras().getString("vetIdapp","defaultKey");
        appdat=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Appointment");
        petdat=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Pet");
        vacdat = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Vaccines");
        meddat=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Medicine");
        actdatabase=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Activity");
        String date = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date());
        String day=date.substring(0,2);
        String month=date.substring(3,5);
        ListView applst=findViewById(R.id.app_listview);
        MyAdapter adapt=new MyAdapter(this,pastappId,pastappuser);
        applst.setAdapter(adapt);
        MyAdapter adapt1=new MyAdapter(this,petnamelist,petIdlist);
        MyAdapter adapt2=new MyAdapter(this,vaccinelst,vaccineidlst);
        int dayy=Integer.parseInt(day.replaceAll("[\\D]", ""));
        int monthh=Integer.parseInt(month.replaceAll("[\\D]", ""));
        MyAdapter adapt3=new MyAdapter(this,medlst,medidlst);
        actdatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counter=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        appdat.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot dataSnapshot) {
                if (pastappuser.isEmpty()){
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                        if (vetID.equals(snapshot.child("vetId").getValue().toString())){
                            appdate=snapshot.child("date").getValue().toString();
                            String apd=appdate.substring(0,2);
                            String apm=appdate.substring(3,5);
                            int apday=Integer.parseInt(apd.replaceAll("[\\D]", ""));
                            int apmonth=Integer.parseInt(apm.replaceAll("[\\D]", ""));
                            if (apmonth<monthh){
                                pastappId.add(snapshot.child("appId").getValue().toString());
                                pastappuser.add(snapshot.child("userId").getValue().toString());
                                datelist.add(snapshot.child("date").getValue().toString());
                                adapt.notifyDataSetChanged();

                            }
                            else if (apmonth==monthh){
                                if (apday<=dayy){
                                    pastappId.add(snapshot.child("appId").getValue().toString());
                                    pastappuser.add(snapshot.child("userId").getValue().toString());
                                    datelist.add(snapshot.child("date").getValue().toString());
                                    adapt.notifyDataSetChanged();
                                }
                            }
                        }
                    }
                }

            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError databaseError) {
            }
        });

        applst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                userId=pastappuser.get(position);
                realdete=datelist.get(position);
                LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);;
                View popupView = layoutInflater.inflate(R.layout.popup_actpet, null);
                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                final PopupWindow popupWindow = new PopupWindow(popupView, 800, 1500, true);
                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                petbut = popupView.findViewById(R.id.buttpet);
                petlst=popupView.findViewById(R.id.petLST);
                petlst.setAdapter(adapt1);
                petbut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        petdat.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull @NotNull DataSnapshot dataSnapshot) {
                                if (petnamelist.isEmpty()){
                                    for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                                        if (userId.equals(snapshot.child("petUserId").getValue().toString())){
                                            petnamelist.add(snapshot.child("petname").getValue().toString());
                                            petIdlist.add(snapshot.child("petId").getValue().toString());
                                            adapt1.notifyDataSetChanged();
                                        }
                                    }
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull @NotNull DatabaseError databaseError) {
                            }
                        });
                        petlst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                popupWindow.dismiss();
                                String petID=petIdlist.get(position);
                                appointmentId=pastappId.get(position);
                                LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);;
                                View popupView1 = layoutInflater.inflate(R.layout.popup_actv, null);
                                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                                final PopupWindow popupWindow = new PopupWindow(popupView1, 800, 1500, true);
                                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                                numPicker=popupView1.findViewById(R.id.actType);
                                getVaclst=popupView1.findViewById(R.id.vaclst);
                                reff=popupView1.findViewById(R.id.refo);
                                numPicker.setMinValue(0);
                                numPicker.setMaxValue(sub.length - 1);
                                numPicker.setDisplayedValues(sub);
                                numPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
                                actbut=popupView1.findViewById(R.id.actadd);
                                infotxt=popupView1.findViewById(R.id.infostext);
                                reff.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        int type=numPicker.getValue();
                                        typee=sub[type];
                                        if (typee.equals("Shaving")){
                                            typee="Shaving";
                                        }
                                        else{
                                            if (typee.equals("Vaccines")){
                                                vacdat.addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        if (vaccineidlst.isEmpty()){
                                                            for (DataSnapshot snapshot1 : dataSnapshot.getChildren()){
                                                                vaccinelst.add(snapshot1.child("vacName").getValue().toString());
                                                                vaccineidlst.add(snapshot1.child("vacID").getValue().toString());
                                                                adapt2.notifyDataSetChanged();
                                                            }
                                                        }
                                                    }
                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                                    }
                                                });
                                                getVaclst.setAdapter(adapt2);
                                                getVaclst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                                    @Override
                                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                                        lastname=vaccinelst.get(position);
                                                        actbut.setVisibility(View.VISIBLE);
                                                    }
                                                });
                                            }
                                            else{
                                                meddat.addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        if (medidlst.isEmpty()){
                                                            for (DataSnapshot snapshot2 : dataSnapshot.getChildren()){
                                                                medlst.add(snapshot2.child("medName").getValue().toString());
                                                                medidlst.add(snapshot2.child("medID").getValue().toString());
                                                                adapt3.notifyDataSetChanged();
                                                            }
                                                        }
                                                    }
                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                                    }
                                                });
                                                getVaclst.setAdapter(adapt3);
                                                getVaclst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                                    @Override
                                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                                        lastname=medlst.get(position);
                                                        actbut.setVisibility(View.VISIBLE);
                                                    }
                                                });
                                            }
                                        }
                                    }
                                });
                                actbut.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        String inf=infotxt.getText().toString();
                                        isApp=true;
                                        PetActivity act = new PetActivity(counter,realdete,petID,vetID,typee,inf,isApp,lastname);
                                        actdatabase.child(act.getActivityId()).setValue(act);
                                        appdat.child(appointmentId).removeValue();
                                    }
                                });
                            }
                        });
                    }
                });
            }
        });

    }

    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        ArrayList<String> name;
        ArrayList<String> id;
        MyAdapter(Context c, ArrayList<String>name,ArrayList<String> id){
            super(c,R.layout.row,R.id.clinic_name, name);
            this.context=c;
            this.name=name;
            this.id=id;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row,parent,false);
            TextView textView = row.findViewById(R.id.clinic_name);
            TextView textView2 = row.findViewById(R.id.clinic_rating);
            textView.setText(name.get(position));
            textView2.setText(id.get(position).toString());
            return row;
        }
    }
}