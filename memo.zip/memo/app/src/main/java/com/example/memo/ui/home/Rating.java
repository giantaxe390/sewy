package com.example.memo.ui.home;

public class Rating {
    double rate;
    String rateId;

    public String getRateId() {
        return rateId;
    }

    public void setRateId(String rateId) {
        this.rateId = rateId;
    }

    String rateUserid;
    String rateVetid;
    boolean isRated;

    public Rating() {
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public String getRateUserid() {
        return rateUserid;
    }

    public void setRateUserid(String rateUserid) {
        this.rateUserid = rateUserid;
    }

    public String getRateVetid() {
        return rateVetid;
    }

    public void setRateVetid(String rateVetid) {
        this.rateVetid = rateVetid;
    }

    public boolean isRated() {
        return isRated;
    }

    public void setRated(boolean rated) {
        isRated = rated;
    }

    public Rating(double rate, String rateUserid, String rateVetid, boolean isRated,String rateid) {
        this.rate = rate;
        this.rateId=rateid;
        this.rateUserid = rateUserid;
        this.rateVetid = rateVetid;
        this.isRated = isRated;
    }
}
