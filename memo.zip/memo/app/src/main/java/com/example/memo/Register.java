 package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.memo.ui.User;
import com.example.memo.ui.profile.Veterinary;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.hbb20.CountryCodePicker;

import java.util.HashMap;

 public class Register extends AppCompatActivity {
    FirebaseDatabase database;
    DatabaseReference ref,ref1,alldatabase;
    Button b;
    Button loginbutton;
    EditText surname;
    EditText username;
    EditText pass;
    EditText mail;
    CountryCodePicker pick;
    EditText phone;
    long counter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Intent intent1 = getIntent();
        b=findViewById(R.id.button);
        pick = findViewById(R.id.ccpRegister);
        phone = findViewById(R.id.phoneTextRegister);
        surname=findViewById(R.id.surname);
        loginbutton=findViewById(R.id.logbutton);
        username=findViewById(R.id.username);
        pass=findViewById(R.id.password);
        mail=findViewById(R.id.e_mail);
        database = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/");
        alldatabase = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        ref= database.getReference().child("User");
        ref1= database.getReference().child("Veterinary");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counter=dataSnapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name=username.getText().toString();
                String surnamee= surname.getText().toString();
                String pas=pass.getText().toString();
                String maill=mail.getText().toString();
                String phonee=phone.getText().toString();
                String country= pick.getSelectedCountryCode().toString();
                User user = new User(name,surnamee,pas,maill,phonee,country,counter++);
                HashMap<String,Object> profileMap = new HashMap<>();
                profileMap.put("userId",user.getUserId());
                profileMap.put("name",user.getName());
                alldatabase.child(user.getUserId()).setValue(profileMap);
                ref.child(user.getUserId()).setValue(user);
                Intent i=new Intent(v.getContext(),MainActivity2.class);
                if(name.length()==0){
                    username.setError("Please register");
                }
                else if(surnamee.length()==0){
                    pass.setError("Please register");
                }
                else if(pas.length()==0){
                    pass.setError("Please register"); 
                }
                else if(maill.length()==0){
                    mail.setError("please register");
                }
                else {
                    Toast.makeText(Register.this, "Registered with mail and password", Toast.LENGTH_SHORT).show();
                }
            }
        });
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent z=new Intent(v.getContext(),login.class);
                startActivity(z);
            }
        });

    }

 }