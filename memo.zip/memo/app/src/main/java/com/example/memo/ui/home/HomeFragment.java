package com.example.memo.ui.home;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.memo.R;
import com.example.memo.totalRating;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.sql.Struct;

public class HomeFragment extends Fragment {

    EditText name;
    EditText phone;
    EditText ratingtext;
    EditText address;
    Button but;
    ImageView imgView;
    String location;
    long ratecounter;
    double rate;
    static double userrate;
    DatabaseReference ref,userref;
    DatabaseReference ref1,ref2;
    String vetID;
    private static String namestr;
    private static boolean rr=false;
    private static long counter;
    String totalrateId;
    private static String phonenumber;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        SharedPreferences pref = this.getActivity().getSharedPreferences("pref",Context.MODE_PRIVATE);
        vetID=pref.getString("vetid","");
        SharedPreferences prefuser = this.getActivity().getSharedPreferences("prefuser", Context.MODE_PRIVATE);
        String userID=prefuser.getString("userid","");
        name=root.findViewById(R.id.editTextTextPersonName);
        imgView=root.findViewById(R.id.vetimager);
        phone=root.findViewById(R.id.editTextPersonName4);
        ratingtext=root.findViewById(R.id.editTextrating);
        address=root.findViewById(R.id.editTextTextPersonName2);
        name.setKeyListener(null);
        phone.setKeyListener(null);
        address.setKeyListener(null);
        ratingtext.setKeyListener(null);
        but=root.findViewById(R.id.button4);
        userref= FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        ref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Veterinary");
        ref1 = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Rating");
        ref2 = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("TotalRating");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    if (vetID.equals(snapshot.child("vetId").getValue().toString())){
                       namestr=snapshot.child("vetName").getValue().toString();
                       phonenumber=snapshot.child("phonenumber").getValue().toString();
                       location=snapshot.child("address").getValue().toString();
                       name.setText("Name:"+namestr);
                       phone.setText("Phone: "+phonenumber);
                       address.setText("Location:"+location);
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        ref2.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    if (vetID.equals(snapshot.child("vetId").getValue().toString())){
                        rate= (double)snapshot.child("rating").getValue();
                        counter= (long) snapshot.child("counter").getValue();
                        ratingtext.setText("Rating: "+rate);
                        totalrateId=snapshot.child("totalrateId").getValue().toString();
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError databaseError) {
            }
        });

        View row=inflater.inflate(R.layout.ratingpopup_window, container, false);
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        RatingBar mRatingBar = row.findViewById(R.id.ratingBar);
        Button ratebutton=row.findViewById(R.id.Rate);
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(row, width, height, focusable);
        ref1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    ratecounter=dataSnapshot.getChildrenCount();
                }
                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                    if (vetID.equals(snapshot.child("rateVetid").getValue().toString()) && userID.equals(snapshot.child("rateUserid").getValue().toString())){
                        rr=true;
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


            but.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (rr){
                        Toast.makeText(getActivity(), "You already Rated :(", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        popupWindow.showAtLocation(root, Gravity.CENTER, 0, 0);
                        mRatingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
                            @Override
                            public void onRatingChanged(RatingBar ratingBar, float v, boolean b) {
                                userrate=v*2;
                            }
                        });
                        ratebutton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                double lastrate=(rate*counter)+userrate;
                                String rateid="Rate"+ratecounter;
                                Rating rating = new Rating(userrate,userID,vetID,true,rateid);
                                ref1.child(rating.getRateId()).setValue(rating);
                                ref2.child(totalrateId).removeValue();
                                counter+=1;
                                double ll=lastrate/counter;
                                int idc=Integer.parseInt(totalrateId.replaceAll("[\\D]", ""));
                                totalRating total=new totalRating(counter,vetID,idc,ll);
                                ref2.child(totalrateId).setValue(total);
                                popupWindow.dismiss();
                            }
                        });
                    }
                }
            });

        retriveVetInfo();


        return root;
    }
    private void retriveVetInfo() {
        userref.child(vetID).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (snapshot.child("image").exists()){
                    String imageDb=snapshot.child("image").getValue().toString();
                    Picasso.get().load(imageDb).placeholder(R.drawable.profile_image).into(imgView);
                }
            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }


}