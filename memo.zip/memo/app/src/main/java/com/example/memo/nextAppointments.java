package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.onesignal.OneSignal;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class nextAppointments extends AppCompatActivity {
    private DatabaseReference appdatRef,allRef;
    private String vetID;
    EditText daytext,timetext;
    Button deleteday;
    private String appdate;
    String userId;
    static ArrayList<String> nextappId = new ArrayList<>();
    static ArrayList<String> nextappuser = new ArrayList<>();
    static ArrayList<String> nextime = new ArrayList<>();
    static ArrayList<String> nextdate = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_next_appointments);
        appdatRef= FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Appointment");
        allRef= FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        vetID = getIntent().getExtras().getString("nextVetId","defaultKey");
        String date = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date());
        String day=date.substring(0,2);
        String month=date.substring(3,5);
        ListView applst=findViewById(R.id.nextapp_listview);
        MyAdapter adapt=new MyAdapter(this,nextappId,nextappuser);
        applst.setAdapter(adapt);
        int dayy=Integer.parseInt(day.replaceAll("[\\D]", ""));
        int monthh=Integer.parseInt(month.replaceAll("[\\D]", ""));
        appdatRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot dataSnapshot) {
                if (nextappuser.isEmpty()){
                    for(DataSnapshot snapshot : dataSnapshot.getChildren()){
                        if (vetID.equals(snapshot.child("vetId").getValue().toString())){
                            appdate=snapshot.child("date").getValue().toString();
                            int apday=Integer.parseInt(appdate.substring(0,2).replaceAll("[\\D]", ""));
                            int apmonth=Integer.parseInt(appdate.substring(3,5).replaceAll("[\\D]", ""));
                            if (apmonth>monthh){
                                nextappId.add(snapshot.child("appId").getValue().toString());
                                nextappuser.add(snapshot.child("userId").getValue().toString());
                                nextime.add(snapshot.child("time").getValue().toString());
                                nextdate.add(snapshot.child("date").getValue().toString());
                                adapt.notifyDataSetChanged();

                            }
                            else if (apmonth==monthh){
                                if (apday>=dayy){
                                    nextappId.add(snapshot.child("appId").getValue().toString());
                                    nextappuser.add(snapshot.child("userId").getValue().toString());
                                    nextime.add(snapshot.child("time").getValue().toString());
                                    nextdate.add(snapshot.child("date").getValue().toString());
                                    adapt.notifyDataSetChanged();
                                }
                            }
                        }
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {
            }
        });
        LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);;
        View popupView = layoutInflater.inflate(R.layout.popup_nextapp, null);
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        final PopupWindow popupWindow = new PopupWindow(popupView, 800, 700, true);
        daytext=popupView.findViewById(R.id.nextappDay);
        timetext=popupView.findViewById(R.id.nextappTime);
        deleteday=popupView.findViewById(R.id.Deletebut);
        applst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String nextTime=nextime.get(position);
                String nextDay=nextdate.get(position);
                String userID=nextappuser.get(position);

                allRef.child(userID).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                        userId=snapshot.child("playerID").getValue().toString();
                    }
                    @Override
                    public void onCancelled(@NonNull @NotNull DatabaseError error) {
                    }
                });
                String appointmentId=nextappId.get(position);
                daytext.setText(nextDay);
                timetext.setText(nextTime);
                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                deleteday.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        appdatRef.child(appointmentId).removeValue();
                        try {
                            OneSignal.postNotification(new JSONObject("{'contents': {'en':'"+"Appointment deleted"+nextTime+"and"+nextDay+"'}, 'include_player_ids': ['" + userId + "']}"), null);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });

    }

    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        ArrayList<String> name;
        ArrayList<String> id;
        MyAdapter(Context c, ArrayList<String>name,ArrayList<String> id){
            super(c,R.layout.row,R.id.clinic_name, name);
            this.context=c;
            this.name=name;
            this.id=id;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row,parent,false);
            TextView textView = row.findViewById(R.id.clinic_name);
            TextView textView2 = row.findViewById(R.id.clinic_rating);
            textView.setText(name.get(position));
            textView2.setText(id.get(position).toString());
            return row;
        }
    }
}