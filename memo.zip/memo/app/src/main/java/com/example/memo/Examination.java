package com.example.memo;

public class Examination {
    String type;
    String examid;
    String medId;
    String vacId;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getExamid() {
        return examid;
    }

    public void setExamid(String examid) {
        this.examid = examid;
    }

    public String getMedId() {
        return medId;
    }

    public void setMedId(String medId) {
        this.medId = medId;
    }

    public String getVacId() {
        return vacId;
    }

    public void setVacId(String vacId) {
        this.vacId = vacId;
    }

    public Examination() {
    }
    public Examination(long s, String typee,String id) {
        this.examid="Examination"+s;
        this.type=typee;
        if (typee.equals("Vaccine")){
            this.vacId=id;
        }
        else{
            this.medId=id;
        }
    }


}
