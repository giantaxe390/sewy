package com.example.memo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.memo.ui.profile.Veterinary;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Admin extends AppCompatActivity {
    Button Vetbutton;
    Button addbutton;
    EditText name;
    EditText Password;
    EditText Vetpass;
    Button actbut;
    EditText Location;
    EditText phonenum;
    long counter;
    private DatabaseReference vetref,tratedat,alldatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        vetref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Veterinary");
        alldatabase = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        tratedat= FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("TotalRating");
        Vetbutton=findViewById(R.id.vetaddbutt);
        addbutton=findViewById(R.id.addbutton);
        name=findViewById(R.id.vetName);
        actbut=findViewById(R.id.addacttype);
        Password=findViewById(R.id.vetPass);
        Vetpass=findViewById(R.id.vetlogpass);
        Location=findViewById(R.id.vetLocation);
        phonenum=findViewById(R.id.vetPhone);

        Vetbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name.setVisibility(View.VISIBLE);
                Password.setVisibility(View.VISIBLE);
                Vetpass.setVisibility(View.VISIBLE);
                Location.setVisibility(View.VISIBLE);
                phonenum.setVisibility(View.VISIBLE);
                addbutton.setVisibility(View.VISIBLE);
            }
        });
        Intent vacmedad=new Intent(this, vacmedAdder.class);

        actbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(vacmedad);
            }
        });

        vetref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counter=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        addbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String vetname=name.getText().toString();
                String password=Password.getText().toString();
                String vetpass=Vetpass.getText().toString();
                String location=Location.getText().toString();
                String phone= phonenum.getText().toString();
                Veterinary vet= new Veterinary(vetname,phone,location,vetpass,counter,password);
                totalRating tt=new totalRating(0,vet.getVetId(),counter,(double) (0.01));
                HashMap<String,Object> profileMap = new HashMap<>();
                profileMap.put("userId",vet.getVetId());
                profileMap.put("name",vet.getVetName());
                alldatabase.child(vet.getVetId()).setValue(profileMap);
                vetref.child(vet.getVetId()).setValue(vet);
                tratedat.child(tt.getTotalrateId()).setValue(tt);
            }
        });

    }
}