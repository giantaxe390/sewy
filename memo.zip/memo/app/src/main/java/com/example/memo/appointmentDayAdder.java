package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class appointmentDayAdder extends AppCompatActivity {
    ListView addedList;
    Button startBut;
    Button endBut;
    Button databaseadder;
    Button deleter;
    long counter;
    String startT;
    private DatabaseReference avApp;
    static ArrayList<String> start = new ArrayList<>();
    static ArrayList<String> end = new ArrayList<>();
    TimePicker timePicker;
    boolean isEmpty;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment_day_adder);
        avApp = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("availableApp");
        startBut=findViewById(R.id.startBut);
        deleter=findViewById(R.id.deleteBut);
        endBut=findViewById(R.id.endBut);
        timePicker=findViewById(R.id.datePicker1);
        MyAdapter adapter=new MyAdapter(this,start,end);
        addedList=findViewById(R.id.timeList);
        addedList.setAdapter(adapter);
        databaseadder=findViewById(R.id.databaseadder);
        String vetID = getIntent().getExtras().getString("VetIDDD","defaultKey");
        String dayy = getIntent().getExtras().getString("day","defaultKey");
        start.clear();
        end.clear();
        avApp.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counter=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        startBut.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                int hour = timePicker.getHour();
                int minute=timePicker.getMinute();
                startT=hour+"."+minute;
                endBut.setVisibility(View.VISIBLE);
            }
        });
        endBut.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                int hour = timePicker.getHour();
                int minute=timePicker.getMinute();
                String etime=hour+"."+minute;
                start.add(startT);
                end.add(etime);
                adapter.notifyDataSetChanged();
                endBut.setVisibility(View.VISIBLE);
            }
        });
        databaseadder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (start.isEmpty()){
                    Toast.makeText(appointmentDayAdder.this,"Add day first",Toast.LENGTH_SHORT).show();
                }
                else {
                    AvDay datTime=new AvDay(counter,vetID,dayy);
                    avApp.child(datTime.getAvailableDay()).setValue(datTime);
                    int i=0;
                    while (i<start.size()){
                        String dataTime =start.get(i)+"-"+end.get(i);
                        final HashMap<String,Object> dataTimer = new HashMap<>();
                        dataTimer.put("empty",false);
                        dataTimer.put("time",dataTime);
                        dataTimer.put("timeId","time"+i);
                        avApp.child(datTime.getAvailableDay()).child("time"+i).setValue(dataTimer);
                        i++;
                    }
                }
            }
        });


        addedList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                deleter.setVisibility(View.VISIBLE);
                deleter.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        start.remove(position);
                        end.remove(position);
                    }
                });
            }
        });

    }
    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        ArrayList<String> starter;
        ArrayList<String> finisher;
        MyAdapter(Context c, ArrayList<String>st,ArrayList<String> en){
            super(c,R.layout.timerrow,R.id.startertime, st);
            this.context=c;
            this.starter=st;
            this.finisher=en;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.timerrow,parent,false);
            TextView textView = row.findViewById(R.id.startertime);
            TextView textView2 = row.findViewById(R.id.endingtime);
            textView.setText(starter.get(position));
            textView2.setText(finisher.get(position).toString());
            return row;
        }
    }
}