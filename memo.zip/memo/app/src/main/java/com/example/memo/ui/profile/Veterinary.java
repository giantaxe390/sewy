package com.example.memo.ui.profile;

public class Veterinary {
    private String vetName;
    private String VetId;
    private String Address;
    private String vetPass;
    private String vetLogpass;
    private String phonenumber;

    public String getVetLogpass(){return vetLogpass;};

    public void setVetLogpass(String passo){
        this.vetLogpass=passo;
    }


    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    private String Users;
    public String getVetPass() {
        return vetPass;
    }

    public void setVetPass(String vetPass) {
        this.vetPass = vetPass;
    }

    public void addUserToVet(String userId){
        this.Users=userId;
    }

    public Veterinary() {
    }

    public String getVetName() {
        return vetName;
    }

    public void setVetName(String vetName) {
        this.vetName = vetName;
    }


    public String getVetId() {
        return VetId;
    }

    public void setVetId(String vetId) {
        VetId = vetId;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public Veterinary(String vetName,String phone, String address,String vetpas,long z,String Password) {
        this.vetName = vetName;
        this.vetPass=Password;
        this.vetLogpass= vetpas;
        this.phonenumber=phone;
        this.VetId = "Vet"+z;
        this.Address = address;
    }
}
