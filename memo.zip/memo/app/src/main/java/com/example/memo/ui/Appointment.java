package com.example.memo.ui;

import java.util.Date;

public class Appointment {
    private String AppId;
    private String userId;
    private String vetId;

    public long getCounterApp() {
        return counterApp;
    }

    public void setCounterApp(long counterApp) {
        this.counterApp = counterApp;
    }

    private long counterApp;
    private String date;
    private String time;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getAppId() {
        return AppId;
    }

    public void setAppId(String appId) {
        AppId = appId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getVetId() {
        return vetId;
    }

    public void setVetId(String vetId) {
        this.vetId = vetId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Appointment(String vetId, long count,String userId,String dayy,String timee) {
        this.counterApp=count;
        this.AppId = "Appointment"+count;
        this.vetId=vetId;
        this.userId=userId;
        this.date=dayy;
        this.time=timee;
    }

    public Appointment() {
    }


}
