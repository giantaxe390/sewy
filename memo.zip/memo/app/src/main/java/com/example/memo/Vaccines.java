package com.example.memo;

public class Vaccines {
    String vacName;
    int duration;
    String info;
    String vacID;
    String examinationId;

    public String getVacName() {
        return vacName;
    }

    public void setVacName(String vacName) {
        this.vacName = vacName;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getVacID() {
        return vacID;
    }

    public void setVacID(String vacID) {
        this.vacID = vacID;
    }

    public String getExaminationId() {
        return examinationId;
    }

    public void setExaminationId(String examinationId) {
        this.examinationId = examinationId;
    }

    public Vaccines() {
    }
    public Vaccines(long s,  String vacn,int duration,String info,String exid) {
        this.vacID="vaccine"+s;
        this.duration=duration;
        this.examinationId=exid;
        this.vacName=vacn;
        this.info=info;
    }


}
