package com.example.memo;

import java.util.Date;

public class PetVet {
    String petId;
    String petVetId;
    String vetID;

    public String getVetId() {
        return vetID;
    }

    public void setVetId(String VetId) {
        this.vetID = VetId;
    }
    public String getPetVetId() {
        return petVetId;
    }

    public void setPetVetId(String petVetId) {
        this.petVetId = petVetId;
    }


    public String getPetId() {
        return petId;
    }

    public void setPetId(String petId) {
        this.petId = petId;
    }

    public PetVet(String petID, long counter,String VetID) {
        this.petVetId = "petVet"+counter;
        this.petId = petID;
        this.vetID=VetID;
    }

    public PetVet() {
    }




}
