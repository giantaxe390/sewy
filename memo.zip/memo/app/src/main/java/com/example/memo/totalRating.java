package com.example.memo;

public class totalRating {
    long counter;
    String vetId;
    String totalrateId;
    double rating;
    long tcounter;



    public long getCounter() {
        return counter;
    }

    public void setCounter(long counter) {
        this.counter = counter;
    }

    public String getVetId() {
        return vetId;
    }

    public void setVetId(String vetId) {
        this.vetId = vetId;
    }

    public totalRating(long counter, String vetId, long tcounter, double rating) {
        this.counter = counter;
        this.vetId = vetId;
        this.totalrateId = "totalrate"+tcounter;
        this.rating = rating;
    }

    public String getTotalrateId() {
        return totalrateId;
    }

    public void setTotalrateId(String totalrateId) {
        this.totalrateId = totalrateId;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }
}
