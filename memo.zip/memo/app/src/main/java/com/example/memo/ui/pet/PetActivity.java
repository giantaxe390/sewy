package com.example.memo.ui.pet;

import java.util.Date;

public class PetActivity {
    String activityId;
    String date;
    String info;

    public String getActmedname() {
        return actmedname;
    }

    public void setActmedname(String actmedname) {
        this.actmedname = actmedname;
    }

    String actmedname;
    boolean isApp;
    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    String petId;
    String vetId;
    String type;

    public boolean isApp() {
        return isApp;
    }

    public void setApp(boolean app) {
        isApp = app;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public PetActivity(long con, String date, String petId, String vetId,String Type,String infoo,boolean is,String rs) {
        this.activityId = "activity"+con;
        this.actmedname=rs;
        this.info=infoo;
        this.type=Type;
        this.isApp=is;
        this.date = date;
        this.petId = petId;
        this.vetId = vetId;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String  getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getPetId() {
        return petId;
    }

    public void setPetId(String petId) {
        this.petId = petId;
    }

    public String getVetId() {
        return vetId;
    }

    public void setVetId(String vetId) {
        this.vetId = vetId;
    }

    public PetActivity() {
    }
}
