package com.example.memo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;

public class CallingActivity extends AppCompatActivity {
    private TextView nameContanct;
    private ImageView profileImage;
    private ImageView cancelCallButn,makeCallBtn;
    private String callingID="",ringingID="";
    private Intent petint;
    private String senderUserId="",senderUserImage="",senderUserName="",checker="";
    private String receiverUserName="",receiverUserId="",receiverImage="";
    private boolean booler;
    private MediaPlayer mediaPlayer;
    DatabaseReference userref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calling);
        userref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");

        receiverUserId = getIntent().getExtras().getString("vetoId","defaultKey");
        senderUserId = getIntent().getExtras().getString("usoId","defaultKey");
        booler=getIntent().getExtras().getBoolean("bool");
        mediaPlayer=MediaPlayer.create(this,R.raw.ringing);
        nameContanct=findViewById(R.id.namecalling);
        profileImage=findViewById(R.id.profileimagecalling);
        cancelCallButn=findViewById(R.id.cancellcall);
        makeCallBtn=findViewById(R.id.makecall);
        cancelCallButn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                checker="clicked";

                cancelCallingUser();
            }
        });
        makeCallBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                final HashMap<String,Object> callingPickUpMap = new HashMap<>();
                callingPickUpMap.put("picked","picked");
                userref.child(senderUserId).child("Ringing")
                        .updateChildren(callingPickUpMap)
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull @NotNull Task<Void> task) {
                                if (task.isComplete()){
                                    Intent intent=new Intent(CallingActivity.this,VideoChatActivity.class);
                                    intent.putExtra("userIden",senderUserId);
                                    intent.putExtra("boller",booler);
                                    startActivity(intent);
                                }
                            }
                        });
            }
        });

        getAndSetUserProfileInfo();
    }



    private void getAndSetUserProfileInfo() {
        userref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (snapshot.child(receiverUserId).exists()){
                    receiverUserName=snapshot.child(receiverUserId).child("name").getValue().toString();
                    if (snapshot.child(receiverUserId).child("image").exists()){
                        receiverImage=snapshot.child(receiverUserId).child("image").getValue().toString();
                        nameContanct.setText(receiverUserName);
                        Picasso.get().load(receiverImage).placeholder(R.drawable.profile_image).into(profileImage);
                    }
                    else{
                        Picasso.get().load(R.drawable.profile_image).placeholder(R.drawable.profile_image).into(profileImage);
                    }

                }
                if (snapshot.child(senderUserId).exists()){
                    senderUserName=snapshot.child(senderUserId).child("name").getValue().toString();
                    if (snapshot.child(senderUserId).child("image").exists()){
                        senderUserImage=snapshot.child(senderUserId).child("image").getValue().toString();
                        Picasso.get().load(senderUserImage).placeholder(R.drawable.profile_image).into(profileImage);
                        nameContanct.setText(senderUserName);
                    }
                    else{
                        Picasso.get().load(R.drawable.profile_image).placeholder(R.drawable.profile_image).into(profileImage);
                    }


                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();
        mediaPlayer.start();
        userref.child(receiverUserId).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (!checker.equals("clicked") && !snapshot.hasChild("Calling") && !snapshot.hasChild("Ringing")){
                    final HashMap<String,Object>callingInfo = new HashMap<>();
                    callingInfo.put("calling",receiverUserId);
                    userref.child(senderUserId).child("Calling")
                            .updateChildren(callingInfo)
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull @NotNull Task<Void> task) {
                                    if (task.isSuccessful()){
                                        final HashMap<String,Object>ringingInfo = new HashMap<>();
                                        ringingInfo.put("ringing",senderUserId);
                                        userref.child(receiverUserId)
                                                .child("Ringing")
                                                .updateChildren(ringingInfo);
                                    }
                                }
                            });
                }
            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });


        userref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (snapshot.child(senderUserId).hasChild("Ringing") && !snapshot.child(senderUserId).hasChild("Calling")){
                    makeCallBtn.setVisibility(View.VISIBLE);
                }
                if (snapshot.child(receiverUserId).child("Ringing").hasChild("picked")){
                    mediaPlayer.stop();
                    Intent intent=new Intent(CallingActivity.this,VideoChatActivity.class);
                    intent.putExtra("userIden",senderUserId);
                    intent.putExtra("boller",booler);
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });
    }
    private void cancelCallingUser() {
        userref.child(senderUserId).child("Calling")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                        if (snapshot.exists() && snapshot.hasChild("calling")){
                            callingID=snapshot.child("calling").getValue().toString();
                            mediaPlayer.stop();
                            userref.child(callingID).child("Ringing").removeValue()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull @NotNull Task<Void> task) {
                                            if (task.isSuccessful()){
                                                userref.child(senderUserId).child("Calling").removeValue()
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull @NotNull Task<Void> task) {
                                                                if (booler){
                                                                    petint=new Intent(CallingActivity.this, BottomNavigationActivity.class);
                                                                    petint.putExtra("calling",1);
                                                                }
                                                                else{
                                                                    petint=new Intent(CallingActivity.this, vetFrag.class);
                                                                }
                                                                startActivity(petint);
                                                                finish();
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                        else {
                            if (booler){
                                petint=new Intent(CallingActivity.this, BottomNavigationActivity.class);
                                petint.putExtra("calling",1);
                            }
                            else{
                                petint=new Intent(CallingActivity.this, vetFrag.class);
                            }
                            startActivity(petint);
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull @NotNull DatabaseError error) {

                    }
                });
        //from receiver side
        userref.child(senderUserId).child("Ringing")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                        if (snapshot.exists() && snapshot.hasChild("ringing")){
                            ringingID=snapshot.child("ringing").getValue().toString();

                            userref.child(ringingID).child("Calling").removeValue()
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull @NotNull Task<Void> task) {
                                            if (task.isSuccessful()){
                                                userref.child(senderUserId).child("Ringing").removeValue()
                                                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                            @Override
                                                            public void onComplete(@NonNull @NotNull Task<Void> task) {
                                                                if (booler){
                                                                    petint=new Intent(CallingActivity.this, BottomNavigationActivity.class);
                                                                    petint.putExtra("calling",1);
                                                                }
                                                                else{
                                                                    petint=new Intent(CallingActivity.this, vetFrag.class);
                                                                }
                                                                startActivity(petint);
                                                                finish();
                                                            }
                                                        });
                                            }
                                        }
                                    });
                        }
                        else {
                            if (booler){
                                petint=new Intent(CallingActivity.this, BottomNavigationActivity.class);
                                petint.putExtra("calling",1);
                            }
                            else{
                                petint=new Intent(CallingActivity.this, vetFrag.class);
                            }
                            startActivity(petint);
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull @NotNull DatabaseError error) {

                    }
                });
    }
}