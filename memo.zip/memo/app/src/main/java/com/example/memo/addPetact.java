package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.NumberPicker;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.TimePicker;

import com.example.memo.ui.pet.PetActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.onesignal.OneSignal;

import org.jetbrains.annotations.NotNull;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class addPetact extends AppCompatActivity {
    Button petfind;
    static ArrayList<String> vaccinelst = new ArrayList<>();
    static ArrayList<String> vaccinedur = new ArrayList<>();
    static ArrayList<String> meddur = new ArrayList<>();
    static ArrayList<String> vaccineidlst = new ArrayList<>();
    static ArrayList<String> users = new ArrayList<>();
    static ArrayList<String> medlst = new ArrayList<>();
    static ArrayList<String> medidlst = new ArrayList<>();
    static ArrayList<String> petlist = new ArrayList<>();
    static ArrayList<String> petnamelist = new ArrayList<>();
    String lastname;
    String typee;
    private String userId;
    private String userID;
    TextView infotxt;
    long counter;
    ListView getVaclst;
    Button actbut;
    Button reff;
    Date future;
    private int durationn;
    boolean isApp;
    final String sub[] ={"Shaving", "Vaccines", "Medicines"};
    ListView petlst;
    NumberPicker numPicker;
    private DatabaseReference petdatabase,actdatabase,shadatabase,vacdat,meddat,allus;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_petact);
        petlst=findViewById(R.id.petlistview);
        String vetID = getIntent().getExtras().getString("VetIDact","defaultKey");
        petfind=findViewById(R.id.petfinder);
        petdatabase = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Pet");
        allus = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("allUsers");
        actdatabase = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Activity");
        shadatabase = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Shaving");
        vacdat = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Vaccines");
        meddat=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Medicine");

        petfind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                finish();
                startActivity(intent);
            }
        });
        actdatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counter=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
        if (petlist.isEmpty()){
            petdatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                        if (snapshot.child("petVetId").getValue().toString().equals(vetID)){
                            petlist.add(snapshot.child("petId").getValue().toString());
                            petnamelist.add(snapshot.child("petname").getValue().toString());
                            users.add(snapshot.child("petUserId").getValue().toString());
                        }
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                }
            });
        }
        MyAdapter adapt=new MyAdapter(this,petnamelist,petlist);
        MyAdapter adapt1=new MyAdapter(this,vaccinelst,vaccineidlst);
        MyAdapter adapt2=new MyAdapter(this,medlst,medidlst);
        petlst.setAdapter(adapt);
        petlst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String petID=petlist.get(position);
                userId=users.get(position);
                //hayvan seç pickerdan activity type seç
                LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);;
                View popupView = layoutInflater.inflate(R.layout.popup_actv, null);
                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                final PopupWindow popupWindow = new PopupWindow(popupView, 800, 1500, true);
                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                numPicker=popupView.findViewById(R.id.actType);
                getVaclst=popupView.findViewById(R.id.vaclst);
                reff=popupView.findViewById(R.id.refo);
                numPicker.setMinValue(0);
                numPicker.setMaxValue(sub.length - 1);
                numPicker.setDisplayedValues(sub);
                numPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
                actbut=popupView.findViewById(R.id.actadd);
                infotxt=popupView.findViewById(R.id.infostext);
                reff.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        int type=numPicker.getValue();
                        typee=sub[type];
                        if (typee.equals("Shaving")){
                            typee="Shaving";
                        }
                        else{
                            if (typee.equals("Vaccines")){
                                vacdat.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (vaccineidlst.isEmpty()){
                                            for (DataSnapshot snapshot1 : dataSnapshot.getChildren()){
                                                vaccinelst.add(snapshot1.child("vacName").getValue().toString());
                                                vaccineidlst.add(snapshot1.child("vacID").getValue().toString());
                                                vaccinedur.add(snapshot1.child("duration").getValue().toString());
                                            }
                                        }
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                    }
                                });
                                getVaclst.setAdapter(adapt1);
                                getVaclst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        lastname=vaccinelst.get(position);
                                        durationn=Integer.parseInt(vaccinedur.get(position).replaceAll("[\\D]", ""));
                                        actbut.setVisibility(View.VISIBLE);
                                    }
                                });
                            }
                            else{
                                meddat.addValueEventListener(new ValueEventListener() {
                                    @Override
                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                        if (medidlst.isEmpty()){
                                            for (DataSnapshot snapshot2 : dataSnapshot.getChildren()){
                                                medlst.add(snapshot2.child("medName").getValue().toString());
                                                medidlst.add(snapshot2.child("medID").getValue().toString());
                                                meddur.add( snapshot2.child("duration").getValue().toString());
                                            }
                                        }
                                    }
                                    @Override
                                    public void onCancelled(@NonNull DatabaseError databaseError) {
                                    }
                                });
                                getVaclst.setAdapter(adapt2);
                                getVaclst.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                                    @Override
                                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                                        lastname=medlst.get(position);
                                        durationn=Integer.parseInt(meddur.get(position).replaceAll("[\\D]", ""));
                                        actbut.setVisibility(View.VISIBLE);
                                    }
                                });
                            }
                        }
                    }
                });
                allus.child(userId).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                        userID=snapshot.child("playerID").getValue().toString();
                    }
                    @Override
                    public void onCancelled(@NonNull @NotNull DatabaseError error) {
                    }
                });
                actbut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String inf=infotxt.getText().toString();
                        isApp=false;
                        String date = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(new Date());
                        PetActivity act = new PetActivity(counter,date,petID,vetID,typee,inf,isApp,lastname);
                        actdatabase.child(act.getActivityId()).setValue(act);
                        Calendar c=Calendar.getInstance();
                        Date today=c.getTime();
                        if (durationn>=30 && durationn<365){
                            durationn=durationn/30;
                            c.add(Calendar.MONTH,durationn);
                            future=c.getTime();
                        }
                        else if (durationn==365){
                            c.add(Calendar.YEAR,1);
                            future=c.getTime();
                        }
                        try {
                            OneSignal.postNotification(new JSONObject("{'contents': {'en':'"+"Next Activity at"+future.toString()+"'}, 'include_player_ids': ['" + userID + "']}"), null);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                });
            }
        });





    }
    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        ArrayList<String> name;
        ArrayList<String> id;
        MyAdapter(Context c, ArrayList<String>name,ArrayList<String> id){
            super(c,R.layout.row,R.id.clinic_name, name);
            this.context=c;
            this.name=name;
            this.id=id;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row,parent,false);
            TextView textView = row.findViewById(R.id.clinic_name);
            TextView textView2 = row.findViewById(R.id.clinic_rating);
            textView.setText(name.get(position));
            textView2.setText(id.get(position).toString());
            return row;
        }
    }
}