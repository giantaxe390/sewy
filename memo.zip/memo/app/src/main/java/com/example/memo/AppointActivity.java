package com.example.memo;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.DatePicker;

public class AppointActivity extends AppCompatActivity {
    DatePicker picker;
    Button but1;
    String appday;
    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent addDay=new Intent(this,appointmentDayAdder.class);
        setContentView(R.layout.activity_appoint);
        picker=findViewById(R.id.Datepicker);
        String vetID = getIntent().getExtras().getString("VetIDD","defaultKey");
        picker.setMinDate(System.currentTimeMillis() - 1000);
        but1=findViewById(R.id.dayButton);
        picker.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
            @Override
            public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                int month=monthOfYear+1;
                if (dayOfMonth<10){
                    String dayy="0"+dayOfMonth;
                    if (month<10){
                        String monthh="0"+month;
                        appday=dayy+"."+monthh+"."+year;
                    }
                    else{
                        appday=dayy+"."+month+"."+year;
                    }
                }
                else {
                    if (month<10){
                        String monthh="0"+month;
                        appday=dayOfMonth+"."+monthh+"."+year;
                    }
                    else {
                        appday=dayOfMonth+"."+month+"."+year;
                    }
                }
                System.out.println(appday);
                but1.setVisibility(View.VISIBLE);
            }
        });
        but1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addDay.putExtra("VetIDDD",vetID);
                addDay.putExtra("day",appday);
                startActivity(addDay);
            }
        });
    }
}