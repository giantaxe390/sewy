package com.example.memo;

public class Medicine {
    String medName;
    int duration;
    String info;
    String medID;
    String examinationId;

    public String getMedName() {
        return medName;
    }

    public void setMedName(String medName) {
        this.medName = medName;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getMedID() {
        return medID;
    }

    public void setMedID(String medID) {
        this.medID = medID;
    }

    public String getExaminationId() {
        return examinationId;
    }

    public void setExaminationId(String examinationId) {
        this.examinationId = examinationId;
    }

    public Medicine() {
    }
    public Medicine(long s,  String medn,int duration,String info,String examid) {
        this.medID="medicine"+s;
        this.examinationId=examid;
        this.duration=duration;
        this.medName=medn;
        this.info=info;
    }


}
