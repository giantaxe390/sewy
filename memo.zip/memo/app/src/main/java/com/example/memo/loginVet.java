package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loginVet extends AppCompatActivity {
    ListView listView;

    static ArrayList<String> list1 = new ArrayList<>();
    static ArrayList<String> list2 = new ArrayList<>();
    private DatabaseReference ref,ref1;
    String vetId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_vet);
        List<Map<String, String>> list = new ArrayList<Map<String, String>>();
        Map<String, String> map;
        int count = list1.size();
        for (int i=0;i<count;i++){
            map = new HashMap<String, String>();
            map.put("name", list1.get(i));
            map.put("rating", list2.get(i));
            list.add(map);
        }
        SimpleAdapter adapter = new SimpleAdapter(this, list, R.layout.row, new String[] { "name", "rating" }, new int[] { R.id.clinic_name, R.id.clinic_rating});
        listView = (ListView)findViewById(R.id.vet_listview);
        listView.setAdapter(adapter);
        ref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Veterinary");
        ref1 = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("TotalRating");
        Intent z=new Intent(this,BottomNavigationActivity.class);
        if (list.isEmpty()){
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot)  {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                        String vetname=snapshot.child("vetName").getValue().toString();
                        list1.add(vetname);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        if (list2.isEmpty()){
            ref1.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot)  {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                        String rating= snapshot.child("rating").getValue().toString();
                        list2.add(rating);
                        System.out.println(list2);
                        adapter.notifyDataSetChanged();
                    }
                    finish();
                    startActivity(getIntent());
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }


        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String vetn=list1.get(position).toString();
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                            if (vetn.equals(snapshot.child("vetName").getValue().toString())){
                                vetId=snapshot.child("vetId").getValue().toString();
                                SharedPreferences pref= getSharedPreferences("pref",Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor=pref.edit();
                                editor.putString("vetid",vetId);
                                editor.apply();
                            }
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);;
                View popupView = layoutInflater.inflate(R.layout.popup_window, null);
                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                Button vetbut=popupView.findViewById(R.id.videoCall);
                EditText pass= popupView.findViewById(R.id.vetPassword);
                TextView text=popupView.findViewById(R.id.textView);
                vetbut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String vetpas=pass.getText().toString();
                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                                    if (vetId.equals(snapshot.child("vetId").getValue().toString())){
                                        String realpass=snapshot.child("vetPass").getValue().toString();
                                        if(vetpas.equals(realpass)){
                                            startActivity(z);
                                            popupWindow.dismiss();
                                            finish();
                                        }
                                        else {
                                            text.setText("yanlıs sifre");
                                        }
                                    }
                                }
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                });
            }
        });

    }

    @Override
    protected void onDestroy() {

        super.onDestroy();
    }
}