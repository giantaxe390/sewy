package com.example.memo.ui.pet;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.memo.CallingActivity;
import com.example.memo.Petallact;
import com.example.memo.R;
import com.example.memo.Sewy;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;

public class PetFragment extends Fragment {

    ListView petlist;
    static ArrayList<String> list = new ArrayList<>();
    static ArrayList<String> list2 = new ArrayList<>();
    private static String petId;
    private DatabaseReference ref,ref1,ref2;
    long counter;
    Date date;
    private static String petname;
    private static String rac;
    private static String petID;
    private static String rac1;
    private static String colour;
    private static String datee;
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_pet, container, false);
        SharedPreferences prefuser = this.getActivity().getSharedPreferences("prefuser", Context.MODE_PRIVATE);
        String userID=prefuser.getString("userid","");
        MyAdapter2 adapt=new MyAdapter2(this.getActivity(),list,list2);
        SharedPreferences pref = this.getActivity().getSharedPreferences("pref", Context.MODE_PRIVATE);
        String vetID=pref.getString("vetid","");
        Intent i = new Intent(getActivity(), CallingActivity.class);
        Intent x = new Intent(getActivity(), Petallact.class);
        ((Activity) getActivity()).overridePendingTransition(0, 0);
        petlist = root.findViewById(R.id.pet_listview);
        ref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Pet");
        ref1 = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Activity");
        ref2 = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Vaccines");
        //    Pet pet=new Pet(userID,vetID,"Cat","Black",date,1,false,"Shivas");
        //    ref.child(pet.getPetId()).setValue(pet);


        if (list.isEmpty()){
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                        String petUid=snapshot.child("petUserId").getValue().toString();
                        String petVid=snapshot.child("petVetId").getValue().toString();
                        if (petUid.equals(userID) && petVid.equals(vetID)){
                            petname=snapshot.child("petname").getValue().toString();
                            rac=snapshot.child("petRacial").getValue().toString();
                            petId=snapshot.child("petId").getValue().toString();
                            list.add(petname);
                            list2.add(rac);
                            adapt.notifyDataSetChanged();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        View row=inflater.inflate(R.layout.popup_petinfo, container, false);
        int width = LinearLayout.LayoutParams.WRAP_CONTENT;
        int height = LinearLayout.LayoutParams.WRAP_CONTENT;
        EditText text1=row.findViewById(R.id.actType);
        EditText text2=row.findViewById(R.id.actDate);
        EditText text3=row.findViewById(R.id.actInfo);
        EditText text4=row.findViewById(R.id.petBirthday);
        Button videocallBut=row.findViewById(R.id.videoCall);
        Button activityBut= row.findViewById(R.id.button3);
        boolean focusable = true; // lets taps outside the popup also dismiss it
        final PopupWindow popupWindow = new PopupWindow(row, 750, 1500, focusable);
        petlist.setAdapter(adapt);
        petlist.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String petname1=list.get(position).toString();
                popupWindow.showAtLocation(root, Gravity.CENTER, 0, 0);
                ref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                            String petname2=snapshot.child("petname").getValue().toString();
                            if (petname1.equals(petname2)){
                                colour=snapshot.child("color").getValue().toString();
                                String day=snapshot.child("birthDate").getValue().toString();
                                rac1=snapshot.child("petRacial").getValue().toString();
                                petId=snapshot.child("petId").getValue().toString();
                                datee= day;
                                petID=petId;

                            }
                        }
                        text1.setText(petname1);
                        text2.setText(rac1);
                        text3.setText(colour);
                        text4.setText(datee);


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                activityBut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                        startActivity(x);
                    }
                });

                videocallBut.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        popupWindow.dismiss();
                        i.putExtra("vetoId",vetID);
                        i.putExtra("usoId",userID);
                        i.putExtra("bool",true);
                        startActivity(i);
                    }
                });


            }
        });

        return root;



    }
    public static String getPetId(){
        return petID;
    };
    class MyAdapter2 extends ArrayAdapter<String> {
        Context context;
        ArrayList<String> name;
        ArrayList<String> rating;
        MyAdapter2(Context c, ArrayList<String>name,ArrayList<String> rating){
            super(c,R.layout.row,R.id.pet_name, name);
            this.context=c;
            this.name=name;
            this.rating=rating;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater inflater = getLayoutInflater();
            View row1;
            row1 = inflater.inflate(R.layout.row1, parent, false);
            TextView textView = row1.findViewById(R.id.pet_name);
            TextView textView2 = row1.findViewById(R.id.pet_id);
            textView.setText(name.get(position));
            textView2.setText(rating.get(position).toString());
            return row1;
        }
    }

}