package com.example.memo.ui;

public class User {
    private String name;
    private String userId;
    private String mail;
    private String surname;

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    private String password;
    private String phone;
    private String country;
    private long counter;
    //private pet


    public User() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


    public User(String name,String surnamee, String password, String mail , String phone,String centroid,long x) {
        this.name = name;
        this.userId = "user"+x;
        this.mail = mail;
        this.surname=surnamee;
        this.password = password;
        this.phone = centroid +phone;
    }
}
