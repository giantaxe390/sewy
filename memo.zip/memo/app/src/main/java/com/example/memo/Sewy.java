package com.example.memo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.memo.ui.home.HomeFragment;
import com.example.memo.ui.pet.PetFragment;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthOptions;
import com.google.firebase.auth.PhoneAuthProvider;
import com.hbb20.CountryCodePicker;

import org.jetbrains.annotations.NotNull;

import java.util.concurrent.TimeUnit;

public class Sewy extends AppCompatActivity {
    private CountryCodePicker pick;
    private EditText phone;
    private EditText codeTxt;
    private Button nextbut;
    private Button caller;
    private String checker = "",phoneNumber ="";
    private RelativeLayout relativeLayout;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;
    private FirebaseAuth mAuth;
    private String mVerificationId;
    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private ProgressDialog loadingBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sewy);
        String vetID = getIntent().getExtras().getString("vetoId","defaultKey");
        String userID = getIntent().getExtras().getString("usoId","defaultKey");
        mAuth=FirebaseAuth.getInstance();
        loadingBar=new ProgressDialog(this);

        phone = findViewById(R.id.phoneText);
        codeTxt=findViewById(R.id.codeText);
        nextbut=findViewById(R.id.continueNextButton);
        relativeLayout=findViewById(R.id.phoneAuth);
        caller=findViewById(R.id.callbtn);
        pick=findViewById(R.id.ccp);
        pick.registerCarrierNumberEditText(phone);
        nextbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nextbut.getText().equals("Submit") || checker.equals("Code Sent"))
                {
                    String verificationCode= codeTxt.getText().toString();
                    if (verificationCode.equals("")){
                        Toast.makeText(Sewy.this, "Please write verification code frst", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        loadingBar.setTitle("Code Verification");
                        loadingBar.setMessage("Please wait, we are verifying code");
                        loadingBar.setCanceledOnTouchOutside(false);
                        loadingBar.show();
                        PhoneAuthCredential credential=PhoneAuthProvider.getCredential(mVerificationId,verificationCode);
                        signInWithPhoneAuthCredential(credential);
                        caller.setVisibility(View.VISIBLE);
                    }
                }
                else{
                    phoneNumber=pick.getFullNumberWithPlus();
                    if (!phoneNumber.equals("")){
                        loadingBar.setTitle("Phone Number Verification");
                        loadingBar.setMessage("Please wait, we are verifying phone number");
                        loadingBar.setCanceledOnTouchOutside(false);
                        loadingBar.show();
                        PhoneAuthOptions options =
                                PhoneAuthOptions.newBuilder(mAuth)
                                        .setPhoneNumber(phoneNumber)       // Phone number to verify
                                        .setTimeout(60L, TimeUnit.SECONDS) // Timeout and unit
                                        .setActivity(Sewy.this)                 // Activity (for callback binding)
                                        .setCallbacks(mCallbacks)          // OnVerificationStateChangedCallbacks
                                        .build();
                        PhoneAuthProvider.verifyPhoneNumber(options);     }
                    else{
                        Toast.makeText(Sewy.this,"Please write valid phone",Toast.LENGTH_LONG);
                    }
                }
            }
        });
        caller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intet=new Intent(v.getContext(),CallingActivity.class);
                System.out.println(vetID);
                intet.putExtra("vetorID",vetID);
                intet.putExtra("usorID",userID);
                startActivity(intet);
                finish();
            }
        });
        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(@NonNull @NotNull PhoneAuthCredential phoneAuthCredential) {
                signInWithPhoneAuthCredential(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(@NonNull @NotNull FirebaseException e) {
                Toast.makeText(Sewy.this, "Invalid Phone Number", Toast.LENGTH_SHORT).show();
                loadingBar.dismiss();
                relativeLayout.setVisibility(View.VISIBLE);
                nextbut.setText("Continue");
                codeTxt.setVisibility(View.GONE);
            }
            @Override
            public void onCodeSent(String s,PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                super.onCodeSent(s,forceResendingToken);
                mVerificationId=s;
                mResendToken=forceResendingToken;
                relativeLayout.setVisibility(View.GONE);
                checker="Code Sent";
                nextbut.setText("Submit");
                codeTxt.setVisibility(View.VISIBLE);
                loadingBar.dismiss();
                Toast.makeText(Sewy.this, "Code has been sent, please check.", Toast.LENGTH_SHORT).show();
            }
        };
    }
    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            loadingBar.dismiss();
                            Toast.makeText(Sewy.this,"Congratulations, you are logged in successfully",Toast.LENGTH_LONG).show();
                        } else {
                            loadingBar.dismiss();
                            String e= task.getException().toString();
                            Toast.makeText(Sewy.this, "Error"+e, Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
    private void sendUserToMainActivity()
    {
        Intent intent = new Intent(Sewy.this, PetFragment.class);
        startActivity(intent);
        finish();
    }
}

