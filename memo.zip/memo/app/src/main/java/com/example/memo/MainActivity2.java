package com.example.memo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity2 extends AppCompatActivity {
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        b1=findViewById(R.id.button2);
        Intent intent = getIntent();
        Intent i1=new Intent(this, Register.class);
        String isim=intent.getStringExtra("username");
        String password=intent.getStringExtra("password");
        String mail=intent.getStringExtra("mail");
        String phone=intent.getStringExtra("phone");
        String country=intent.getStringExtra("country");
        TextView tv1=findViewById(R.id.main2_mail);
        TextView tv2=findViewById(R.id.main2_username);
        TextView tv3=findViewById(R.id.main2_password);
        TextView tv4=findViewById(R.id.main2_phone);
        TextView tv5=findViewById(R.id.main2_country);
        tv1.setText(isim);
        tv2.setText(password);
        tv3.setText(mail);
        tv4.setText(phone);
        tv5.setText(country);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(i1);
            }
        });
    }
}