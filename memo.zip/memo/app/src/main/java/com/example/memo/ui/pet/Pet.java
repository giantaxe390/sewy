package com.example.memo.ui.pet;

import java.util.Date;

public class Pet {
    String petUserId;
    String petname;
    String petVetId;
    String petRacial;
    String Color;
    String BirthDate;
    String petId;

    public String getPetname() {
        return petname;
    }

    public void setPetname(String petname) {
        this.petname = petname;
    }




    //Vaccine
    //Appointment
    public String getPetUserId() {
        return petUserId;
    }

    public void setPetUserId(String petUserId) {
        this.petUserId = petUserId;
    }

    public String getPetVetId() {
        return petVetId;
    }

    public void setPetVetId(String petVetId) {
        this.petVetId = petVetId;
    }

    public String getPetRacial() {
        return petRacial;
    }

    public void setPetRacial(String petRacial) {
        this.petRacial = petRacial;
    }

    public String getColor() {
        return Color;
    }

    public void setColor(String color) {
        this.Color = color;
    }

    public String getBirthDate() {
        return BirthDate;
    }

    public void setBirthDate(String birthDate) {
        this.BirthDate = birthDate;
    }

    public String getPetId() {
        return petId;
    }

    public void setPetId(String petId) {
        this.petId = petId;
    }

    public Pet(String petUserId, String petVetId, String petRacial, String color, String birthDate, long count,String nname) {
        this.petUserId = petUserId;
        this.petname=nname;
        this.petVetId = petVetId;
        this.petRacial = petRacial;
        Color = color;
        BirthDate = birthDate;
        this.petId = "pet"+count;
    }

    public Pet() {
    }




}
