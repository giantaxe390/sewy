package com.example.memo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.example.memo.ui.pet.Pet;
import com.example.memo.ui.pet.PetFragment;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Date;

public class Petallact extends AppCompatActivity {
    ListView listView;
    String type;
    String vetid;
    String info;
    String date;
    static ArrayList<String> list = new ArrayList<>();
    static ArrayList<String> list2 = new ArrayList<>();
    static ArrayList<String> datelist= new ArrayList<>();
    static ArrayList<String> infolist = new ArrayList<>();
    private DatabaseReference ref;
    String petIDf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_petallact);
        listView = (ListView)findViewById(R.id.petact_listview);
        ref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Activity");
        Intent z=new Intent(this, PetFragment.class);
        MyAdapter adapt=new MyAdapter(this,list,list2);
        listView.setAdapter(adapt);
        petIDf=PetFragment.getPetId();
        if (list.isEmpty()){
            ref.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        if (snapshot.child("petId").getValue().toString().equals(petIDf)) {
                            type = snapshot.child("type").getValue().toString();
                            vetid = snapshot.child("vetId").getValue().toString();
                            info=snapshot.child("info").getValue().toString();
                            date=snapshot.child("date").getValue().toString();
                            list.add(type);
                            list2.add(vetid);
                            datelist.add(date);
                            infolist.add(info);
                            adapt.notifyDataSetChanged();
                        }
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);;
                View popupView = layoutInflater.inflate(R.layout.popup_petactinfos, null);
                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                String lastdate=datelist.get(position);
                String lastinfo=infolist.get(position);
                String lasttype=list.get(position);
                boolean focusable = true; // lets taps outside the popup also dismiss it
                final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);
                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);
                EditText edit=popupView.findViewById(R.id.actDate);
                EditText edit1=popupView.findViewById(R.id.actInfo);
                EditText edit2=popupView.findViewById(R.id.actType);
                edit.setText(lastdate);
                edit1.setText(lastinfo);
                edit2.setText(petIDf);
            }
        });


    }
    class MyAdapter extends ArrayAdapter<String> {
        Context context;
        ArrayList<String> name;
        ArrayList<String> rating;
        MyAdapter(Context c, ArrayList<String>name,ArrayList<String> rating){
            super(c,R.layout.row,R.id.clinic_name, name);
            this.context=c;
            this.name=name;
            this.rating=rating;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater= (LayoutInflater)getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            View row = layoutInflater.inflate(R.layout.row,parent,false);
            TextView textView = row.findViewById(R.id.clinic_name);
            TextView textView2 = row.findViewById(R.id.clinic_rating);
            textView.setText(name.get(position));
            textView2.setText(rating.get(position).toString());
            return row;
        }
    }
}