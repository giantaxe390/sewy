package com.example.memo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

public class vacmedAdder extends AppCompatActivity {
    Button adder;
    EditText txt1;
    EditText txt2;
    NumberPicker numPicker;
    long ct,ct1;
    EditText txt3;
    DatabaseReference ref,ref1,ref2;
    final String sub1[] ={"Vaccines", "Medicines"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vacmed_adder);
        adder=findViewById(R.id.button6);
        ref=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Vaccines");
        ref1=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Medicine");
        ref2=FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Examination");
        txt1=findViewById(R.id.durationEdittext);
        txt3=findViewById(R.id.nameEdittext);
        txt2=findViewById(R.id.infoEdittext);
        numPicker=findViewById(R.id.typepicker);
        numPicker.setMinValue(0);
        numPicker.setMaxValue(sub1.length - 1);
        numPicker.setDisplayedValues(sub1);
        numPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    ct=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError databaseError) {
            }
        });
        ref1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    ct1=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError databaseError) {
            }
        });
        adder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int dur=Integer.parseInt(txt1.getText().toString());
                String nam=txt3.getText().toString();
                String inf=txt2.getText().toString();
                int type=numPicker.getValue();
                String tip=sub1[type];
                if (tip.equals("Vaccines")){
                    Examination ex1=new Examination((ct1+ct)-2,"Vaccines","vaccine"+ct);
                    ref2.child(ex1.getExamid()).setValue(ex1);
                    Vaccines vac=new Vaccines(ct,nam,dur,inf,ex1.getExamid());
                    ref.child(vac.getVacID()).setValue(vac);
                }
                else {
                    Examination ex=new Examination((ct1+ct)-2,"Medicine","medicine"+ct1);
                    ref2.child(ex.getExamid()).setValue(ex);
                    Medicine med=new Medicine(ct1,nam,dur,inf,ex.getExamid());
                    ref1.child(med.getMedID()).setValue(med);
                }
            }
        });
    }
}