package com.example.memo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.memo.ui.User;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class login extends AppCompatActivity {
    Button login;
    Button register;
    Button vetlog;
    Button admin;
    EditText mail;
    EditText pass;
    boolean fat=false;
    private DatabaseReference ref,ref1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (ContextCompat.checkSelfPermission(login.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(login.this, new String[]{Manifest.permission.CALL_PHONE},1);
        }
        setContentView(R.layout.activity_login);
        vetlog=findViewById(R.id.vetlog);
        admin=findViewById(R.id.butadmin);
        mail=findViewById(R.id.loguser);
        pass=findViewById(R.id.logpass);
        login=findViewById(R.id.logbut);
        register=findViewById(R.id.regbut);
        ref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("User");
        ref1 = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Veterinary");
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String logmail=mail.getText().toString();
                String logpass=pass.getText().toString();
                Intent z=new Intent(v.getContext(),loginVet.class);
                if(logmail.length()==0){
                    mail.setError("Register smth");
                }
                else if(logpass.length()==0){
                    pass.setError("Register smth");
                }
                else{

                        ref.addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                                    String email=snapshot.child("mail").getValue().toString();
                                    if (email.equals(logmail)){
                                        fat=true;
                                        String pass=snapshot.child("password").getValue().toString();
                                        if (pass.equals(logpass)){
                                            String UserId=snapshot.child("userId").getValue().toString();
                                            SharedPreferences prefuser= getSharedPreferences("prefuser", Context.MODE_PRIVATE);
                                            SharedPreferences.Editor editor=prefuser.edit();
                                            editor.putString("userid",UserId);
                                            editor.apply();

                                            z.putExtra("username",logmail);
                                            z.putExtra("password",logpass);
                                            startActivity(z);
                                            finish();
                                        }
                                        else{
                                            Toast.makeText(login.this, "Cant login with this password", Toast.LENGTH_SHORT).show();
                                        }
                                    }


                                }
                                if(!fat){
                                    Toast.makeText(login.this, "There is no name with this.", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                }
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s=new Intent(v.getContext(), Register.class);
                startActivity(s);
                finish();
            }
        });
        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //id:giant pass:texas
                String logmail=mail.getText().toString();
                String logpass=pass.getText().toString();
                Intent k=new Intent(v.getContext(),Admin.class);
                if(logmail.length()==0){
                    mail.setError("Register smth");
                }
                else if(logpass.length()==0){
                    pass.setError("Register smth");
                }
                else{
                    if (logmail.equals("admin")){
                        if (logpass.equals("texas")){
                            startActivity(k);
                            finish();
                        }
                    }
                }
            }
        });
        vetlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String logmail=mail.getText().toString();
                String logpass=pass.getText().toString();
                Intent vet=new Intent(v.getContext(),vetFrag.class);
                if(logmail.length()==0){
                    mail.setError("Register smth");
                }
                else if(logpass.length()==0){
                    pass.setError("Register smth");
                }
                else{
                    ref1.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                                String vetname=snapshot.child("vetName").getValue().toString();
                                if (vetname.equals(logmail)){
                                    fat=true;
                                    String vetpass=snapshot.child("vetLogpass").getValue().toString();
                                    if (vetpass.equals(logpass)){
                                        String vetId=snapshot.child("vetId").getValue().toString();
                                        vet.putExtra("VetID",vetId);
                                        startActivity(vet);
                                        finish();
                                    }
                                    else{
                                        Toast.makeText(login.this, "Cant login with this password", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                            if(!fat){
                                Toast.makeText(login.this, "There is no name with this.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }
        });
    }
}