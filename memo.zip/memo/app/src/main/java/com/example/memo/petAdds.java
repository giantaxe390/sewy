package com.example.memo;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.memo.ui.pet.Pet;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class  petAdds extends AppCompatActivity {
    Button addPet;
    EditText userID;
    EditText racial;
    EditText color;
    private boolean ispet=false;
    private boolean isvetpet=false;
    private boolean isdifvet=false;
    private String petID;
    EditText birthdate;
    EditText petname;
    long counter;
    long counter2;
    private DatabaseReference addPetref,petVetref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pet_adds);
        addPetref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Pet");
        petVetref = FirebaseDatabase.getInstance("https://sewy-c8939-default-rtdb.firebaseio.com/").getReference().child("Vet-Pet");
        addPet=findViewById(R.id.petadder);
        userID=findViewById(R.id.petuserID);
        racial=findViewById(R.id.Racial);
        color=findViewById(R.id.color);
        birthdate=findViewById(R.id.birthdate);
        petname=findViewById(R.id.petname);
        String vetID = getIntent().getExtras().getString("VetID","defaultKey");

        addPetref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counter=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        petVetref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    counter2=dataSnapshot.getChildrenCount();
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        addPet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String userId = userID.getText().toString();
                String rac=racial.getText().toString();
                String col=color.getText().toString();
                String petn=petname.getText().toString();
                String datex = birthdate.getText().toString();

                Pet pet=new Pet(userId,vetID,rac,col,datex,counter,petn);
                petID=pet.getPetId();
                addPetref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            if (userId.equals(snapshot.child("petUserId").getValue().toString()) && petn.equals(snapshot.child("petname").getValue().toString())) {
                                ispet=true;
                                if (vetID.equals(snapshot.child("petVetId").getValue().toString())) {
                                    isvetpet=true;
                                    Toast.makeText(petAdds.this, "Already created Pet", Toast.LENGTH_SHORT).show();
                                    break;
                                }
                            }
                        }
                    };
                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                });
                if (!isvetpet){
                    petVetref.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            for (DataSnapshot snapshot : dataSnapshot.getChildren()){

                                if (vetID.equals(snapshot.child("vetId").getValue().toString()) && petID.equals(snapshot.child("petId").getValue().toString())){
                                    isdifvet=true;
                                    Toast.makeText(petAdds.this, "Already created Pet", Toast.LENGTH_SHORT).show();
                                    break;
                                }
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {
                        }
                    });
                    if (!isdifvet){
                        PetVet petVet = new PetVet(petID,counter2,vetID);
                        petVetref.child(petVet.getPetVetId()).setValue(petVet);
                    }
                }
                if (!ispet){
                    addPetref.child(pet.getPetId()).setValue(pet);
                    //addPetref.child(pet.getPetId()).child(pet.getPetId()).setValue(pet);   // denemdim appoğintment için
                    PetVet petVet = new PetVet(pet.getPetId(),counter2,vetID);
                    petVetref.child(petVet.getPetVetId()).setValue(petVet);
                }




            }
        });


    }
}