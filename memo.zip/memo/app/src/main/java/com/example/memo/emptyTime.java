package com.example.memo;

public class emptyTime {
    String timeId;

    public String getTimeId() {
        return timeId;
    }

    public void setTimeId(String timeId) {
        this.timeId = timeId;
    }

    String time;
    boolean isEmpty;

    public String getTime() {
        return time;
    }

    public emptyTime(String time, boolean isEmpty,long counter) {
        this.time = time;
        this.timeId="time"+counter;
        this.isEmpty = isEmpty;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public boolean isEmpty() {
        return isEmpty;
    }

    public void setEmpty(boolean empty) {
        isEmpty = empty;
    }
}
